from PyQt6.QtCore import QObject, pyqtSignal
import socket
import struct
import threading
import time

BATCH_SIZE = 128
TCP_HOST   = "127.0.0.1"
TCP_PORT   = 54321

class SocketReceiver(QObject):
    batch_received = pyqtSignal(list, list)
    pre_received   = pyqtSignal(float)
    post_received  = pyqtSignal(float)

    def __init__(self):
        super().__init__()
        self.running = False
        self.client  = None

    def start(self):
        self.running = True
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        while self.running:
            try:
                self.client.connect((TCP_HOST, TCP_PORT))
                break
            except ConnectionRefusedError:
                time.sleep(0.1)

        BATCH_BYTES = BATCH_SIZE * 2 * 4

        def recv_exact(sock, n):
            data = b''
            while len(data) < n:
                chunk = sock.recv(n - len(data))
                if not chunk:
                    return None
                data += chunk
            return data

        try:
            while self.running:
                raw = recv_exact(self.client, BATCH_BYTES)
                if raw is None:
                    time.sleep(0.05)
                    continue
                floats     = struct.unpack(f'<{BATCH_SIZE * 2}f', raw)
                pre_batch  = floats[0::2]
                post_batch = floats[1::2]
                self.batch_received.emit(list(pre_batch), list(post_batch))
                self.pre_received.emit(pre_batch[0])
                self.post_received.emit(post_batch[0])
        finally:
            self.client.close()

    def send_json(self, json_data):
        if self.client is None:
            return
        try:
            msg = (json_data + "\n").encode('utf-8')
            self.client.sendall(msg)
        except (BrokenPipeError, OSError):
            print("Socket closed")

    def stop(self):
        self.running = False